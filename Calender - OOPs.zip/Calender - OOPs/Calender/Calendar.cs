﻿//Complete




using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Windows.Forms;

namespace Calender
{
    public partial class Calendar : Form
    {
        //public static int static_year;
        //public static int static_month;
        public int month, year;
        public string eventDescriptions;
        public DateTime currentDate;
        public bool setEvent=false;
        public bool deletDone = false;

        public Dictionary<string, string> eventsData = new Dictionary<string, string>();



        public string path = "Events.txt";

        public Calendar()//Constructor of Calender
        {
            InitializeComponent();

            timerForClock.Start();
            DateTime currentDateTime = DateTime.Now;
            month = currentDateTime.Month;
            year = currentDateTime.Year;

        }


        private void timerForClock_Tick(object sender, EventArgs e)
        {
            DateTime dateTime = DateTime.Now;
            string date = dateTime.ToString("D");
            string AMP = dateTime.ToString("tt");
            lblTime.Text = dateTime.ToString("HH:mm:ss");
            lblDate.Text = date;
            lblAPM.Text=AMP;
            if (setEvent || deletDone) {
                datesTable.Controls.Clear();
                DisplayCalender();
                setEvent = false;
                deletDone = false;
            }
        }

 
        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {


            if (File.Exists(path))
            {
                using (StreamReader reader = new StreamReader(path))
                {
                    string[] lines;
                    string line = reader.ReadLine();
                    string keys, values;
                    while (line != null)
                    {
                        lines = line.Split(',');

                        keys = lines[0] + "," + lines[1];
                        values = lines[2];
                        eventsData[keys] = values;
                        line = reader.ReadLine();
                    }
                }
            }
            else {
                StreamWriter strm = File.CreateText(path);
                strm.Close();
                using (StreamReader reader = new StreamReader(path))
                {
                    string[] lines;
                    string line = reader.ReadLine();
                    string keys, values;
                    while (line != null)
                    {
                        lines = line.Split(',');

                        keys = lines[0] + "," + lines[1];
                        values = lines[2];
                        eventsData[keys] = values;
                        line = reader.ReadLine();
                    }
                }
            }

            DisplayCalender();

        }


        public void DisplayCalender() {
            string monthName = DateTimeFormatInfo.CurrentInfo.GetMonthName(month);
            //static_year = year;
            //static_month = month;

            DateTime StartsWithMonth = new DateTime(year, month, 1);
            int daysInMonth = DateTime.DaysInMonth(year, month);

            int previousMonth = month != 1 ? month - 1 : 12;

            int dayOfWeek = Convert.ToInt32(StartsWithMonth.DayOfWeek.ToString("d"));
            int previousMonthsDays = DateTime.DaysInMonth(year,previousMonth);
            int X = 0;
            int Y = 0;
            int dateDay;

            lblMonYear.Text =monthName + " " + year;
            string descriptions = "";
            eventDescription.Clear();
            eventDescriptions = "";


            for (int dayNumber = 0; dayNumber <42; dayNumber++)
            {
                X = dayNumber % 7 * 55;
                Y = dayNumber / 7 * 47;


                if (dayNumber < dayOfWeek  || dayNumber >= daysInMonth+dayOfWeek)
                {
                    dateDay = dayNumber >= daysInMonth+ dayOfWeek ? dayNumber - dayOfWeek - daysInMonth+1 : previousMonthsDays-dayOfWeek + dayNumber+1;
                    OtherMonthsDateBox dateBox = new OtherMonthsDateBox(this,new Point(X, Y),dateDay);//location, textForDate
                    datesTable.Controls.Add(dateBox);
                }

                else
                {
                    dateDay = dayNumber - dayOfWeek + 1;
                    CurrentMonthsDateBox displayDate = new CurrentMonthsDateBox(this, new Point(X, Y), dateDay);
                    
                    foreach (string key in eventsData.Keys) {

                        if (key==$"{month:00},{dateDay:00}") {//00 will show number in two digits format
                            displayDate.changeColor();
                            descriptions = eventsData[key];
                            eventDescription.Text = eventDescription.Text +$"{monthName} {dateDay},{descriptions}\n" ;
                        }
                    }
                    currentDate = new DateTime(year, month, dateDay);

                    if (currentDate.Date==DateTime.Now.Date) {
                        displayDate.MarkCurrentDate();
                    }
                    datesTable.Controls.Add(displayDate);
                }
            }

        }


        private void Previous_Click(object sender, EventArgs e)
        {
            month--;

            if (month <1)
            {
                month = 12;
                year--;
            }
            datesTable.Controls.Clear();
            DisplayCalender();
        }


        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void eventDescription_TextChanged(object sender, EventArgs e)
        {

        }



        private void Next_Click(object sender, EventArgs e)
        {
            month++;
            if (month > 12){ 
                    month = 1;
                    year++;
            }
            datesTable.Controls.Clear();
            DisplayCalender();

        }
    }
}
