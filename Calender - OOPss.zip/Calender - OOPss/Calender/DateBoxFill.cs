﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace Calender
{
    public partial class DateBoxFill : UserControl
    {
        public int dateOfDay;
        public Calendar calendar;
        public DateBoxFill(Calendar calender, Point location, int dateOftheDay)
        {
            InitializeComponent();
            Location = location;
            dateOfDay = dateOftheDay;
            calendar = calender;
            
            ShowDateOfDay(dateOftheDay);

        }

        private void DateBoxFill_Load(object sender, EventArgs e)
        {
            
        }
        private void DateBoxFill_MouseIn(object sender, EventArgs e)
        {
            BackColor = Color.Red;
        }
        public void ShowDateOfDay(int numDay)
        {
            btnDateFill.Text = numDay+"";
            string eventDate = $"{calendar.month:00},{Convert.ToInt32(btnDateFill.Text):00}";
            if (calendar.eventsData.ContainsKey(eventDate))
            {
                ttpDescription.SetToolTip(btnDateFill, calendar.eventsData[eventDate]);
            }
            
        }
        public void changeColor() 
        {
            btnDateFill.BackColor= Color.FromArgb(255, 0, 0); 
        }
        public void MarkCurrentDate() {
            btnDateFill.FlatAppearance.BorderSize = 3;
            btnDateFill.FlatAppearance.BorderColor = Color.FromArgb(50,50,200);

        }

        private void btnDateFill_Click(object sender, EventArgs e)
        {

            bool keyExist = false;

            EventSavingForm EventNow = new EventSavingForm(this);
            foreach (var item in calendar.eventsData)
            {
                if (item.Key == $"{calendar.month:00},{Convert.ToInt32(dateOfDay):00}")
                {
                    keyExist = true;
                    break;

                }

            }
            if (keyExist)
            {
                EventNow.txtEvent.Text = calendar.eventsData[$"{calendar.month:00},{Convert.ToInt32(dateOfDay):00}"];
                //Console.WriteLine(calendar.eventsData[$"{calendar.month:00},{Convert.ToInt32(static_day):00}"]);

            }
            EventNow.ShowDialog();
            if (calendar.setEvent)
            {
                btnDateFill.BackColor = Color.FromArgb(255, 0, 0);
            }
            if (calendar.deletDone)
            {
                btnDateFill.BackColor = Color.FromArgb(40, 40, 40);
            }
        }
    }
    class CurrentMonthsDateBox: DateBoxFill 
    {
        public CurrentMonthsDateBox(Calendar calendar,Point location, int dateOftheDay) : base(calendar, location, dateOftheDay)
        {
            
        }

    }
    class OtherMonthsDateBox : DateBoxFill
    {

        public OtherMonthsDateBox(Calendar calendar, Point location,int dateOftheDay) : base(calendar, location, dateOftheDay)
        {
            Enabled = false;
        }
    }
}
