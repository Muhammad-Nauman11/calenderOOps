﻿//Complete




using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace Calender
{
    public partial class Calendar : Form
    {
        public int month, year;
        public string eventDescriptions;
        public DateTime currentDate;
        public bool setEvent = false;
        public bool deletDone = false;
        Month displayedMonth;

        public Dictionary<string, string> eventsData = new Dictionary<string, string>();



        public string path = "Events.txt";

        public Calendar()//Constructor of Calender
        {
            InitializeComponent();

            timerForClock.Start();
            DateTime currentDateTime = DateTime.Now;
            month = currentDateTime.Month;
            year = currentDateTime.Year;
            displayedMonth = new Month(month, year);

        }


        private void timerForClock_Tick(object sender, EventArgs e)
        {
            DateTime dateTime = DateTime.Now;
            string date = dateTime.ToString("D");
            string AMP = dateTime.ToString("tt");
            lblTime.Text = dateTime.ToString("HH:mm:ss");
            lblDate.Text = date;
            lblAPM.Text = AMP;
            if (setEvent || deletDone)
            {
                datesTable.Controls.Clear();
                DisplayCalender();
                setEvent = false;
                deletDone = false;
            }
        }


        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {


            if (File.Exists(path))
            {
                using (StreamReader reader = new StreamReader(path))
                {
                    string[] lines;
                    string line = reader.ReadLine();
                    string keys, values;
                    while (line != null)
                    {
                        lines = line.Split(',');

                        keys = lines[0] + "," + lines[1];
                        values = lines[2];
                        eventsData[keys] = values;
                        line = reader.ReadLine();
                    }
                }
            }
            else
            {
                StreamWriter strm = File.CreateText(path);
                strm.Close();
                using (StreamReader reader = new StreamReader(path))
                {
                    string[] lines;
                    string line = reader.ReadLine();
                    string keys, values;
                    while (line != null)
                    {
                        lines = line.Split(',');

                        keys = lines[0] + "," + lines[1];
                        values = lines[2];
                        eventsData[keys] = values;
                        line = reader.ReadLine();
                    }
                }
            }

            DisplayCalender();

        }


        public void DisplayCalender()
        {

            lblMonYear.Text = displayedMonth.monthName + " " + year;
            string descriptions = "";
            eventDescription.Clear();
            eventDescriptions = "";



            int X = 0;
            int Y = 0;

            for (int dayNumber = 0; dayNumber < 42; dayNumber++)
            {
                X = dayNumber % 7 * 55;
                Y = dayNumber / 7 * 47;
                DateBoxFill dateBox = new DateBoxFill(this, new Point(X, Y), Math.Abs(displayedMonth.allDates[dayNumber]));
                dateBox.Enabled = displayedMonth.allDates[dayNumber]<0;
                datesTable.Controls.Add(dateBox);
            }
        }



        public void UpdateCalendar() 
        {
            displayedMonth = new Month(month,year);
            foreach (var item in displayedMonth.allDates)
            {
                datesTable.Controls[item.Key].Controls[0].Text = $"{Math.Abs(item.Value)} ";
                datesTable.Controls[item.Key].Enabled = item.Value < 0;
            }
            
        }
        private void Previous_Click(object sender, EventArgs e)
        {
            month--;

            if (month < 1)
            {
                month = 12;
                year--;
            }
            UpdateCalendar();

        }


        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void eventDescription_TextChanged(object sender, EventArgs e)
        {

        }



        private void Next_Click(object sender, EventArgs e)
        {
            month++;
            if (month > 12)
            {
                month = 1;
                year++;
            }
            UpdateCalendar();


        }

        class Month
        {
            public Dictionary<int,int> allDates=new Dictionary<int, int>();//currentMonthsDates, previousMonthsDates, nextMonthsDates;
            public string monthName;
            public int month, year;
            public int daysInMonth;
            public Month(int month,int year)
            {
                this.month = month;
                this.year = year;
                monthName = DateTimeFormatInfo.CurrentInfo.GetMonthName(month);

                
                daysInMonth = DateTime.DaysInMonth(year, month);

                GenerateDatesForMonth();


            }

            public void GenerateDatesForMonth() 
            {
                DateTime StartsWithMonth = new DateTime(year, month, 1);
                int previousMonth = month != 1 ? month - 1 : 12;

                int dayOfWeek = Convert.ToInt32(StartsWithMonth.DayOfWeek.ToString("d"));
                int previousMonthsDays = DateTime.DaysInMonth(year, previousMonth);
                int dateDay;
                for (int iDate=0; iDate<42;iDate++) 
                {
                    if (iDate < dayOfWeek)
                    {
                        dateDay = previousMonthsDays - dayOfWeek + iDate+1;
                        
                    }
                    else if (iDate > dayOfWeek+daysInMonth-1)
                    {
                        dateDay = iDate - daysInMonth - dayOfWeek + 1;
                    }
                    else 
                    {
                        dateDay = -(iDate  - dayOfWeek + 1);
                    }
                    allDates.Add(iDate,dateDay);
                }

            }
        }
    }
}


